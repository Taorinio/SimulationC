﻿using System;

[Serializable] public class ProgressTable
{
    public float Damage;
    public float Delay;
    public float LevelRequirement;
}
